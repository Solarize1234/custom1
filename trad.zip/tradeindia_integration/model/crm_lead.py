import urllib
import urllib.error
import json
import requests
from odoo import api, fields, models
from odoo.exceptions import UserError
# from datetime import date, datetime, time
from datetime import timedelta, datetime, date
import urllib.request

class AppURLopener(urllib.request.FancyURLopener):
    version = "Mozilla/5.0, Chrome/89.0"


class CRMLead(models.Model):
    _inherit = "crm.lead"





    def create_enquiry_from_tradeindia(self):
        trade_obj = self.env['tradeindia'].search([])
        for record in trade_obj:

            from_date = date.today().strftime('%Y-%m-%d')
            tomorrow = date.today() + timedelta(days=1)
            to_date = tomorrow.strftime('%Y-%m-%d')

            opener = AppURLopener()
            response = opener.open(
                "https://www.tradeindia.com/utils/my_inquiry.html?userid=" + record.user_id + "&profile_id=" + record.profile_id + "&key=" + record.key + "&from_date=" + from_date + "&to_date=" + to_date)
            data = json.loads(response.read())

            start_date = datetime.today() - timedelta(days=3)
            start_date = start_date.strftime('%Y-%m-%d 00:00:00')
            end_date = datetime.today().strftime('%Y-%m-%d 23:59:59')
            crm_obj = self.env["crm.lead"].search(['|', ('active', '!=', False), ('active', '=', False),
                                                   ('create_date', '>=', start_date), ('create_date', '<=', end_date)])
            for team in data:
                # archive_lead_record = archive_lead.filtered(lambda x: x.rfi_id == team.get('rfi_id'))
                # lead_record = crm_lead_obj.search([('rfi_id', '=', team.get('rfi_id'))])

                lead_record = crm_obj.filtered(lambda x: x.rfi_id == team.get('rfi_id'))

                state_obj = self.env['res.country.state'].search([('name', '=', team.get('sender_state'))])
                country_obj = self.env['res.country'].search([('name', '=', team.get('sender_country'))])

                if not lead_record:
                    lead = self.env['crm.lead'].sudo().create({
                            'rfi_id': team.get('rfi_id'),
                            'sender_uid': team.get('sender_uid'),
                            'generated': team.get('generated'),
                            'name': team.get('subject') or "",
                            'contact_name': team.get('sender_name') or False,
                            'partner_name': team.get('sender_co') or False,
                            'email_from': team.get('sender_email') or False,
                            'mobile':team.get('sender_mobile') or False,
                            'street': team.get('address') or False,
                            'fax_no': team.get('fax_number') or False,
                            'inquiry_type': team.get('inquiry_type') or False,
                            'member_since': team.get('member_since') or False,
                            'city': team.get('sender_city') or False,
                            'state_id': state_obj.id or False,
                            'country_id':country_obj.id or False,
                            'product': team.get('product_id') or False,
                            'product_id':team.get('product_name') or False,
                            'product_src': team.get('product_source') or False,
                            'qty': team.get('quantity') or False,
                            'description':team.get('message') or False,
                            'order_value_min':team.get('order_value_min') or False,
                            'pref_supp_location': team.get('pref_supp_location') or False,
                            # 'email_alt':team.get('sender_other_emails') or False,
                            # 'mobile_alt':team.get('sender_other_mobiles') or False,
                            'phone': team.get('landline_number') or False,
                            'source_id': record.source_id.id or False,
                            'company_id': record.company_id.id or False,
                        })
                    if lead:
                        lead.user_id = False
                        lead.team_id = False


