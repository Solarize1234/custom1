
from odoo import api, fields, models, _
from datetime import date, datetime, timedelta

class TradeIndia(models.Model):
    _name = "tradeindia"
    _rec_name = "user_id"

    # name = fields.Char(string="Name")
    user_id = fields.Char(string="User ID")
    profile_id = fields.Char(string="Profile ID")
    key = fields.Char(string="Key")
    from_date = fields.Date(string="From Date", default=fields.Date.today())
    to_date = fields.Date(string="To Date", default=fields.Date.today())
    source_id = fields.Many2one('utm.source', string="Source")
    company_id = fields.Many2one('res.company', string="Company")
