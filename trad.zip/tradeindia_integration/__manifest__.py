# -*- coding: utf-8 -*-

{
    'name': 'TradeIndia Integration',
    'version': '0.1',
    'category': 'contact',
    'author': 'Parthvi Patel',
    'description': """TradeIndia Integration""",
    'summary': 'TradeIndia Integration',
    'website': 'http://www.teknovativesolution.com/',
    'images': [],
    'depends': ['contacts','base','crm','indiamart_integration'],
    'data': [
            'security/ir.model.access.csv',
            'data/scheduler.xml',
            #'views/crm_lead.xml',
            'views/tradeindia.xml',


            ],
            'qweb' :[],
    'installable': True,
    'application': True,
    'auto_install': False,
}

