
from odoo import api, fields, models, _
from datetime import date, datetime, timedelta

class IndiaMart(models.Model):
    _name = "indiamart"

    name = fields.Char(string="Name")
    mobile = fields.Char(string="Mobile")
    key = fields.Char(string="Key")
    company_id = fields.Many2one('res.company', string="Company")
    source_id = fields.Many2one('utm.source',string="Source")