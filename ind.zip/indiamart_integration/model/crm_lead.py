import urllib
import urllib.error
# import urllib2
import json
import requests
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import date, datetime, time,timedelta
import logging
_logger = logging.getLogger(__name__)

class CRMLead(models.Model):
    _inherit = "crm.lead"

    query_id = fields.Char(string="Query ID")
    receive_datetime = fields.Char(string="Receive Datetime")
    enq_mobile = fields.Char(string="Enquiry Mobile")
    call_duration = fields.Char(strung="Call Duration")
    product_id = fields.Char(string="Product")
    inquiry_type = fields.Char(string="Inquiry Type")

    rfi_id = fields.Char(string="RFI ID")
    generated = fields.Integer(string="Generated")
    fax_no = fields.Char(string="Fax No.")
    member_since = fields.Char(string="Member Since")
    order_value_min = fields.Integer(string="Order Value Min")
    pref_supp_location = fields.Char(string="Pref Supp. Location")
    product = fields.Char(string="Product ID")
    product_src = fields.Char(string="Product Source")
    qty = fields.Char(string="Quantity")
    sender_uid = fields.Integer(string="Sender ID")

    def create_enquiry_from_api(self):
        indiamart_obj = self.env['indiamart'].search([])
        context = dict(self._context) or {}
        context.update({'integration_lead': True})
        end_time = datetime.today().strftime('%d-%m-%Y')
        yesterday = datetime.today() - timedelta(days=1)
        start_time = yesterday.strftime('%d-%m-%Y')
        for record in indiamart_obj:
            url = "https://mapi.indiamart.com/wservce/crm/crmListing/v2/?glusr_crm_key=" + record.key + "&start_time=" + start_time + "&end_time=" + end_time
            response = urllib.request.urlopen(url)
            data = json.loads(response.read())
            if data and data.get('MESSAGE'):
                continue

            start_date = datetime.today() - timedelta(days=3)
            start_date = start_date.strftime('%Y-%m-%d 00:00:00')
            end_date = datetime.today().strftime('%Y-%m-%d 23:59:59')
            crm_obj = self.env["crm.lead"].search(['|', ('active', '!=', False), ('active', '=', False),
                                                   ('create_date', '>=', start_date), ('create_date', '<=', end_date)])

            val = data.get('RESPONSE')
            for team in val:
                cmr_record = crm_obj.filtered(
                    lambda lead: lead.query_id and lead.query_id == team.get('UNIQUE_QUERY_ID'))
                # _logger.info("============================indiamart crm_record : %s ", cmr_record)

                # archive_record =crm_archive.filtered(lambda x: x.query_id == team.get('UNIQUE_QUERY_ID'))
                country_obj = self.env['res.country'].search([('code', '=', team.get('SENDER_COUNTRY_ISO'))])
                state_obj = self.env['res.country.state'].search([('name', '=', team.get('SENDER_STATE'))])
                if not cmr_record:
                    lead = self.env['crm.lead'].sudo().with_context(context).create({
                        'query_id': team.get('UNIQUE_QUERY_ID'),
                        'name': team.get('SENDER_NAME') or "",
                        'partner_name': team.get('SENDER_COMPANY') or False,
                        'contact_name': team.get('SENDER_NAME') or False,
                        'email_from': team.get('SENDER_EMAIL') or False,
                        'mobile': team.get('SENDER_MOBILE') and team.get('SENDER_MOBILE').replace('-', '') or False,
                        'street': team.get('SENDER_ADDRESS') or False,
                        'city': team.get('SENDER_CITY') or False,
                        'state_id': state_obj.id or False,
                        'country_id': country_obj.id or False,
                        'product_id': team.get('QUERY_PRODUCT_NAME') or False,
                        'description': team.get('QUERY_MESSAGE') or False,
                        'source_id': record.source_id.id or False,
                        'company_id': record.company_id.id or False,
                        'receive_datetime': team.get('QUERY_TIME') or False,
                        'enq_mobile': team.get('RECEIVER_MOBILE') or False,
                        'call_duration': team.get('CALL_DURATION') or False,
                        'inquiry_type':team.get('QUERY_TYPE') or False,
                        'user_id':False,
                        'team_id':False
                    })


