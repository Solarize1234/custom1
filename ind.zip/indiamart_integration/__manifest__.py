# -*- coding: utf-8 -*-

{
    'name': 'Indiamart Integration',
    'version': '0.1',
    'category': 'contact',
    'author': 'Parthvi Patel',
    'description': """Indiamart Integration""",
    'summary': 'Indiamart Integration',
    'website': 'http://www.teknovativesolution.com/',
    'images': [],
    'depends': ['contacts','crm'],
    'data': [
            'security/ir.model.access.csv',
            'views/indiamart.xml',
            'views/crm_lead.xml',
            'data/scheduler.xml',
            ],
            'qweb' :[],
    'installable': True,
    'application': True,
    'auto_install': False,
}

